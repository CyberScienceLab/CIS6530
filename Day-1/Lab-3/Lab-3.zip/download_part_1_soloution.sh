wget https://raw.githubusercontent.com/CyberScienceLab/CIS6530/main/Day-1/Lab-3/Lab-3-Final.ipynb
